﻿**Token Averaging for Efficient Language Model Training**
### <a name="_np1rpbc620lv"></a>**Project Summary**
-----
## <a name="_tkdq75qx2l10"></a>**Hypothesis**
Standard transformer training processes tokens one-by-one within a fixed context window of length *L*. We investigate **token averaging**: before the transformer processes any input, every *k* consecutive token embeddings are averaged into a single vector. The transformer then operates on a compressed sequence of length *L*, but each position carries information from *k* original tokens : giving an effective context of *k × L*.

The key claim is that for the same FLOPs budget, a token-averaging model can consume *k×* more raw training data than a standard model, as the transformer sees *1/k* the number of positions per raw token. If the transformer can learn from averaged representations, this is a free efficiency gain.

-----
## <a name="_war13h2jl4il"></a>**Method**
Token embeddings are averaged before the first transformer layer. No architecture changes to the transformer itself. The averaging is a static, parameter-free operation : no additional learnable weights.

Raw tokens:  [t1, t2, t3, t4, t5, t6]

k=2 average: [avg(t1,t2), avg(t3,t4), avg(t5,t6)]   ← transformer sees this

k=4 average: [avg(t1..t4), avg(t5..t8)]               ← transformer sees this

**FLOPs accounting:** For averaging factor *k*, the transformer processes sequences *k×* shorter, so FLOPs per raw token = *6N/k*. To match a standard model's FLOPs budget, an averaging model trains on *k×* more raw tokens.

-----
## <a name="_mvdk5yhtjgbm"></a>**Experiments**
All models trained on FineWeb (web text), using the GPT-NeoX tokenizer (vocab: 50,277).
### <a name="_i6qs4h3ugih9"></a>**Scale 1 : 8M Parameters**

|**Model**|**Context**|**k**|**Tokens**|**Final Eval Loss**|
| :-: | :-: | :-: | :-: | :-: |
|Standard baseline|512|1|300M|5\.757|
|Standard 2× context|1024|1|300M|6\.086|
|Averaging k=2|512|2|600M|5\.964|
|Averaging k=4|512|4|800M|6\.273|

At 8M scale, averaging did not outperform the baseline. The technique appears to require a minimum model capacity to benefit from the wider effective context.
### <a name="_67ggipn5c1ra"></a>**Scale 2 : 50M Parameters**
All models trained to approximately the same compute budget (~4.54–4.62 × 10¹⁷ FLOPs):

|**Model**|**Eff. Context**|**k**|**Tokens Seen**|**Eval Loss**|
| :-: | :-: | :-: | :-: | :-: |
|Standard baseline|1024|1|1\.00B|5\.015|
|Standard 2× context|2048|1|1\.00B|5\.028|
|Averaging k=2, ctx=512|1024|2|2\.04B|4\.266|
|Averaging k=2|2048|2|2\.00B|4\.289|
|Averaging k=4|4096|4|4\.07B|**4.131**|
|Averaging k=8|8192|8|8\.14B|4\.307|
|Mixed k=2/4|3072|~3|3\.05B|5\.023|

-----
## <a name="_qgf2ipimwwz5"></a>**Key Results**
**1. Averaging consistently beats standard training at equal FLOPs (50M scale)**

At identical compute, k=2 averaging achieves **0.73 lower loss** than the standard baseline (4.289 vs 5.015). k=4 achieves **0.88 lower loss** (4.131 vs 5.015). Simply doubling the context window (model2\_50m\_ctx2n) gave no improvement (5.028).

**2. There is a sweet spot : k=4 is optimal, k=8 degrades**

|**k**|**Eval Loss**|
| :-: | :-: |
|1 (baseline)|5\.015|
|2|4\.289|
|4|4\.131 ← best|
|8|4\.307|

Beyond k=4, averaging blends too much information into a single vector, and the transformer struggles to extract useful signal.

**3. Averaging is more compute-efficient than extending context**

The standard 2× context model (model2\_50m\_ctx2n) used the same FLOPs as the baseline and achieved essentially identical loss (5.028 vs 5.015). Token averaging at k=2 with the same FLOPs achieved 4.289 : demonstrating that the gain comes from seeing more raw data, not from a larger attention window alone.

**4. Scale dependency**

The technique showed no benefit at 8M parameters but strong benefit at 50M. This suggests a minimum model capacity is required to effectively decode averaged representations.

-----
## <a name="_beoj20dwug3n"></a>**Summary**
Token averaging is a simple, zero-parameter modification to the standard LM training loop that allows a fixed-size transformer to consume *k×* more raw training data within the same FLOPs budget. At 50M parameters, this yields a consistent and significant reduction in cross-entropy loss across all tested averaging factors (k=2,4), with k=4 producing the largest gain. The technique scales better than naive context extension and introduces no architectural overhead.

The next natural step is validating these findings at 400M–1B parameter scale, where the gains are expected to compound and the optimal *k* may shift further.
















**Appendix A : Data & Results**

**Code Repository:[ ](https://github.com/cyai/llm-token-averaging/tree/working)[github.com/cyai/llm-token-averaging](https://github.com/cyai/llm-token-averaging/tree/working)** (working branch) **Plotting scripts:**experiments/chinchilla/plot\_50m\_models.py, plot\_8m\_models.py **FLOPs formula used throughout:** FLOPs/sequence = N\_layers × L × (24d² + 4Ld) where L = context\_len

-----
### <a name="_powxhvjh8gzg"></a>**A.1 : Model Configurations**
**8M Scale** (d=128, h=4, l=6, trained on FineWeb)

|**Model**|**Context**|**k**|**Target Tokens**|**Chinchilla D\***|
| :-: | :-: | :-: | :-: | :-: |
|model1\_8m|512|1|300M|~160M|
|model2\_8m\_ctx2n|1024|1|300M|~160M|
|avg\_8m\_k2|512|2|600M|~320M|
|avg\_8m\_k4|512|4|800M|~640M|

**50M Scale** (d=512, h=8, l=8, trained on FineWeb)

|**Model**|**Context**|**k**|**Eff. Context**|**Target Tokens**|**Chinchilla D\***|
| :-: | :-: | :-: | :-: | :-: | :-: |
|model1\_50m|1024|1|1024|1B|~1.02B|
|model2\_50m\_ctx2n|2048|1|2048|1B|~1.02B|
|avg\_50m\_k2\_ctx512|512|2|1024|2B|~2.04B|
|avg\_50m\_k2|1024|2|2048|2B|~2.04B|
|avg\_50m\_mixed\_k2k4|1024|~3|3072|3B|~3.05B|
|avg\_50m\_k4|1024|4|4096|4B|~4.07B|
|avg\_50m\_k8|1024|8|8192|8B|~8.14B|

-----
### <a name="_fbj2u94nnk8y"></a>**A.2 : Final Loss Values**
**8M Models** (all at ~2.52 × 10¹⁵ FLOPs)

|**Model**|**Final Eval Loss**|
| :-: | :-: |
|model1\_8m|5\.757|
|model2\_8m\_ctx2n|6\.086|
|avg\_8m\_k2|5\.964|
|avg\_8m\_k4|6\.273|

**50M Models** (all at ~4.54–4.62 × 10¹⁷ FLOPs)

|**Model**|**Tokens Seen**|**FLOPs**|**Final Eval Loss**|
| :-: | :-: | :-: | :-: |
|model1\_50m|1\.00B|4\.540e+17|5\.015|
|model2\_50m\_ctx2n|1\.00B|4\.540e+17|5\.028|
|avg\_50m\_k2\_ctx512|2\.04B|4\.621e+17|4\.266|
|avg\_50m\_k2|2\.00B|4\.540e+17|4\.289|
|avg\_50m\_mixed\_k2k4|3\.05B|4\.621e+17|5\.023|
|avg\_50m\_k4|4\.07B|4\.621e+17|**4.131**|
|avg\_50m\_k8|8\.14B|4\.621e+17|4\.307|

-----
###
### <a name="_y6g5xzn3jcrh"></a><a name="_dsqhgn47t5cl"></a>**A.3 : Loss Curves: 8M Models**

**Figure A.1** : Loss vs Tokens Seen (8M)

![ref1]

At equal token budgets, the standard baseline (blue) outperforms all averaging variants at 8M scale. Extending context to 2× (orange) also underperforms the baseline : both the context extension and averaging approaches fail to recover at this model size, suggesting insufficient model capacity to utilise longer-range information.

**Figure A.2** : Loss vs FLOPs (8M, log scale)

![ref2]

On a FLOPs-aligned axis, the 2× context model (orange) appears shifted right : it spends more compute per step due to the longer sequences : and its loss trajectory is worse per FLOP. The standard baseline and averaging models land in similar FLOPs regimes, with the standard model maintaining the lead.

-----
### <a name="_dyx7tcuacp6g"></a>**A.4 : Loss Curves: 50M Models**
**Figure A.3** : Loss vs Tokens Seen (50M, linear scale)

![](Aspose.Words.4289086a-2b82-4548-ba43-dc5b77082ac8.003.png)

Averaging models (k=2, k=4) achieve substantially lower loss by consuming more raw tokens within the same compute budget. ★ markers indicate the Chinchilla-optimal point (D\* = 20N) for each model. All trained models reach approximately their Chinchilla-optimal token count. The k=4 model achieves the lowest final loss among runs completed to ~4.6 × 10¹⁷ FLOPs.

**Figure A.4** : Loss vs Tokens Seen (50M, log scale)

![ref3]

Log scale reveals the early training dynamics. All models start from equivalent random initialisation loss and diverge as they accumulate more tokens. Averaging models follow steeper descent curves in loss-per-token space, reflecting their wider effective context.

**Figure A.5** : Loss vs FLOPs (50M, linear scale)

![ref4]

The central result of the 50M experiments. At identical FLOPs (~4.54 × 10¹⁷), averaging models k=2 and k=4 end significantly lower than both the standard baseline and the 2× context extension. The 2× context model (orange) spends the same FLOPs as the baseline but achieves identical loss : confirming that a larger attention window alone is insufficient; the gain requires seeing more raw data.

**Figure A.6** : Loss vs FLOPs (50M, log scale)

![ref5]

Log-scale FLOPs view confirms that the averaging models track below the baselines throughout training, not just at the endpoint : the advantage is consistent, not a late-training artefact.

-----
### <a name="_lwa63dl1c2fh"></a>**A.6 : Chinchilla Scaling Reference**
Loss predictions from Hoffmann et al. (2022): L(N, D) = A/N^α + B/D^β + E

|**Constant**|**Value**|
| :-: | :-: |
|A|406\.4|
|α|0\.3392|
|B|410\.7|
|β|0\.2849|
|E (irreducible)|1\.6934|

Chinchilla-optimal token count: D\* = 20N. For averaging models, the transformer token count D\_transformer = D\_raw / k, so the raw token budget target = 20 × N × k.



[ref1]: Aspose.Words.4289086a-2b82-4548-ba43-dc5b77082ac8.001.png
[ref2]: Aspose.Words.4289086a-2b82-4548-ba43-dc5b77082ac8.002.png
[ref3]: Aspose.Words.4289086a-2b82-4548-ba43-dc5b77082ac8.004.png
[ref4]: Aspose.Words.4289086a-2b82-4548-ba43-dc5b77082ac8.005.png
[ref5]: Aspose.Words.4289086a-2b82-4548-ba43-dc5b77082ac8.006.png
